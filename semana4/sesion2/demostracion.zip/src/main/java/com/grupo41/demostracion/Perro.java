package com.grupo41.demostracion;

public class Perro {
    public String nombre;
    public String raza;
    public int edad;
    public String imagen;

    public Perro(String nombre, String raza, int edad, String imagen) {
        this.nombre = nombre;
        this.raza = raza;
        this.edad = edad;
        this.imagen = imagen;
    }
}
