package com.grupo41.demostracion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemostracionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemostracionApplication.class, args);
	}

}
